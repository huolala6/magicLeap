import Store from '@/store'
import TransformControls from '@/three/controls/TransformControls'
import { ModelAnimate } from './ModelMethods'

let transformCtrl = null
/**
 * 针对child 的增删查改隐藏显示等
 */
export class EditorMethods {
  /*
  * 添加时，添加transformControl,添加选中状态
  * */
  static add (ObjectName, uuid, value) {
    let obj = Store.state[ObjectName]
    obj[uuid] = value
    Store.commit('setStateData', { name: ObjectName, value: obj })
    CoverageMethods.add(ObjectName, uuid, value)
    SelectAction.selectObject(value)
  }
  static update (ObjectName, uuid, valueName, valueVal) {
    let obj = Store.state[ObjectName]
    obj[uuid][valueName] = valueVal
    Store.commit('setStateData', { name: ObjectName, value: obj })
  }
  /*
   * 删除时，删除本身、删除helper、清除当前项、在图层区删除
   * 删除模型在动画中的绑定函数
   * */
  static remove (ObjectName, uuid) {
    let obj = Store.state[ObjectName]
    let object = obj[uuid]
    delete obj[uuid]
    Store.commit('setStateData', { name: ObjectName, value: obj })
    CoverageMethods.remove(uuid)
    SelectAction.removeObject(uuid)
    let scene = Store.state.globalObject.DEFAULT_SCENE
    if (object && object.help_obj) { scene.remove(object.help_obj) }
    if (object && object._model_obj_name) { object = object[object._model_obj_name] }
    scene.remove(object)
    ModelAnimate.removeTimer(uuid)
  }
}

/*
 * 选中、隐藏、删除
 * 需要判断是否是模型
 * */
export class SelectAction {
  static selectObject (data) {
    let object = data
    if (data && data._model_obj_name) { object = data[data._model_obj_name] }
    let CurrentObject = Store.state.CurrentObject
    if (CurrentObject && object && CurrentObject.uuid === object.uuid) { return }
    Store.commit('setStateData', { name: 'CurrentObject', value: object })
    // 清除transformCtrl
    TransformCtrl.removeOther()
    if (object !== null && !/camera/.test(object.type.toLowerCase())) {
      // 添加transformCtrl
      TransformCtrl.addCtrol(object)
    }
  }
  /*
  * @param [ObjectName] store中的名称
  * 如果隐藏的是当前项，那么把transformCtrl也关闭
  * */
  static visiableObject (ObjectName, data) {
    let object = data
    if (data && data._model_obj_name) { object = data[data._model_obj_name] }
    let CurrentObject = Store.state.CurrentObject
    object.visible = !object.visible
    if (CurrentObject && CurrentObject.uuid === object.uuid) {
      Store.commit('setStateData', { name: 'CurrentObject', value: object })
      if (object.visible) { TransformCtrl.addCtrol(object) } else { TransformCtrl.removeOther() }
    }
    EditorMethods.update(ObjectName, object.uuid, 'visible', object.visible)
  }
  // 删除
  static removeObject (uuid) {
    let CurrentObject = Store.state.CurrentObject
    if (CurrentObject && CurrentObject.uuid === uuid) {
      Store.commit('setStateData', { name: 'CurrentObject', value: {} })
    }
    TransformCtrl.removeOther()
  }
}

/*
 * 图层区
 * */
export class CoverageMethods {
  // 添加到图层数据中
  static add (storeName, uuid, value) {
    let list = Store.state.coverageList
    let key = value._model_info_title ? value._model_info_title : (value.geometry ? value.geometry.type : value.type)
    list.push({ uuid: uuid, key: key, storeName: storeName })
    Store.commit('setStateData', { name: 'coverageList', value: list })
  }
  // 从图层区删除
  static remove (uuid) {
    let list = Store.state.coverageList
    for (let i = 0; i < list.length; i++) {
      if (list[i].uuid === uuid) {
        list.splice(i, 1)
        break
      }
    }
  }
}

/*
 * 处理transformControl
 * */
export class TransformCtrl {
  constructor (globalObject) {
    if (!transformCtrl) {
      transformCtrl = new TransformControls(globalObject.DEFAULT_CAMERA, globalObject.rederer.domElement)
      globalObject.DEFAULT_SCENE.add(transformCtrl)
      window.addEventListener('keydown', this.bindKeyBoard.bind(this), false)
      transformCtrl.addEventListener('change', this.changeToUpdate.bind(this), false)
      // 关闭OrbitControl
      transformCtrl.addEventListener('dragging-changed', (event) => {
        if (globalObject.OrbitControl) {
          globalObject.OrbitControl.enabled = !event.value
        }
      }, false)
      return transformCtrl
    } else {
      return transformCtrl
    }
  }

  static addCtrol (mesh) {
    if (!transformCtrl) { transformCtrl = new TransformCtrl(Store.state.globalObject) }
    transformCtrl.attach(mesh)
  }

  static removeOther () {
    if (!transformCtrl) { transformCtrl = new TransformCtrl(Store.state.globalObject) }
    transformCtrl.detach()
  }

  changeToUpdate () {
    let object = transformCtrl.object
    if (object !== undefined) {
      // 更新当前的helper
      if (object.help_obj) { object.help_obj.update() }
      // 更新store 中数据
    }
  }

  bindKeyBoard (event) {
    switch (event.keyCode) {
      case 81: // Q
        transformCtrl.setSpace(transformCtrl.space === 'local' ? 'world' : 'local')
        break
      case 87: // W
        transformCtrl.setMode('translate')
        break
      case 69: // E
        transformCtrl.setMode('rotate')
        break
      case 82: // R
        transformCtrl.setMode('scale')
        break
      case 187:
      case 107: // +, =, num+
        transformCtrl.setSize(transformCtrl.size + 0.1)
        break
      case 189:
      case 109: // -, _, num-
        transformCtrl.setSize(Math.max(transformCtrl.size - 0.1, 0.1))
        break
      case 32: // Spacebar
        transformCtrl.enabled = !transformCtrl.enabled
        break
    }
  }
}
