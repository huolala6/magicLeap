/**
 * 初始化编辑器
 */
import {
  WebGLRenderer,
  Scene,
  Color,
  // AxesHelper,
  AmbientLight,
  PlaneBufferGeometry,
  MeshPhongMaterial,
  Mesh,
  PerspectiveCamera,
  GridHelper
} from 'three'
import Signals from 'signals' // 把某个函数加入到已经在触发的函数中
import OrbitControls from 'three-orbitcontrols'
import { EditorClick } from '@/utils/EditorClick'

export class BasicInitEditor {
  constructor (parentEl, offset) {
    let EL = parentEl || document.body
    let W = this.getRenderSize(offset).W
    let H = this.getRenderSize(offset).H
    this.offsetSize = offset
    this.initSignalsObject()
    this.initRender(EL, W, H)
    this.initScene()
    this.initCamera(W, H)
    this.initGrid()
    this.initAmbientLight()
    this.initOrbitControl()
    this.initCtrl()

    this.initAnimate()
    this.initResize()
    this.globalRAF()
    return this
  }

  // 获取canvas窗口宽高
  getRenderSize (offset) {
    let { left = 0, top = 0, right = 0, bottom = 0 } = offset
    let W = window.innerWidth - left - right
    let H = window.innerHeight - top - bottom
    return { W: W, H: H }
  }

  // 注册事件监听器
  initSignalsObject () {
    this.Signals = {
      requestAnimationFrame: new Signals(),
      windowResize: new Signals()
    }
  }

  initRender (EL, W, H) {
    this.rederer = new WebGLRenderer({ antialias: true, alpha: true })
    this.rederer.setSize(W, H)
    this.rederer.setClearColor(0xffffff, 0)
    this.rederer.shadowMap.enabled = true
    this.rederer.autoClear = false
    this.rederer.setPixelRatio(window.devicePixelRatio)
    EL.appendChild(this.rederer.domElement)
    console.log('rederer 渲染器创建完成', this.rederer)
  }

  initScene () {
    this.DEFAULT_SCENE = new Scene()
    this.DEFAULT_SCENE.background = new Color(0xcccccc)
    console.log('场景创建完成', this.DEFAULT_SCENE)
    // 辅助工具
    // this.DEFAULT_SCENE_HELPER = new AxesHelper(50)
    // this.DEFAULT_SCENE.add(this.DEFAULT_SCENE_HELPER)
    // console.log('场景辅助工具创建完成', this.DEFAULT_SCENE_HELPER)
  }

  initCamera (W, H) {
    this.DEFAULT_CAMERA = new PerspectiveCamera(45, W / H, 1, 20000)
    this.DEFAULT_CAMERA.position.set(0, 200, 500)
    console.log('默认相机创建完成', this.DEFAULT_CAMERA)
  }

  initGrid () {
    let geometry = new PlaneBufferGeometry(2000, 2000)
    let material = new MeshPhongMaterial({ color: 0x999999, depthWrite: false })
    let ground = new Mesh(geometry, material)
    ground.position.set(0, -5, 0)
    ground.rotation.x = -Math.PI / 2
    ground.receiveShadow = true
    this.DEFAULT_SCENE.add(ground)

    this.DEFAULT_GRID = new GridHelper(2000, 100, 0x000000, 0x000000)
    this.DEFAULT_GRID.material.opacity = 0.2
    this.DEFAULT_GRID.material.transparent = true
    this.DEFAULT_GRID.position.y = -5
    console.log('网格线创建完成', this.DEFAULT_GRID)
    this.DEFAULT_SCENE.add(this.DEFAULT_GRID)
  }

  // 默认创建一个环境灯
  initAmbientLight () {
    this.AmbientLight = new AmbientLight(0xeeeeee, 1)
    console.log('环境灯创建完成', this.AmbientLight)
    this.DEFAULT_SCENE.add(this.AmbientLight)
  }

  initOrbitControl () {
    this.OrbitControl = new OrbitControls(this.DEFAULT_CAMERA, this.rederer.domElement)
    // 使动画循环使用时阻尼或自转 意思是否有惯性
    this.OrbitControl.enableDamping = true
    // 是否可以缩放
    this.OrbitControl.enableZoom = true
    // 设置相机距离原点的最远距离
    this.OrbitControl.minDistance = 0
    // 设置相机距离原点的最远距离
    this.OrbitControl.maxDistance = 2000
    this.OrbitControl.update()
  }

  initCtrl () {
    const a = new EditorClick(this)
    console.log('初始化 选择事件', a)
  }

  initAnimate () {
    this.Signals.requestAnimationFrame.add(() => {
      if (this.OrbitControl) { this.OrbitControl.update() }
      this.rederer.render(this.DEFAULT_SCENE, this.DEFAULT_CAMERA)
    })
  }

  initResize () {
    this.Signals.windowResize.add(() => {
      let W = this.getRenderSize(this.offsetSize).W
      let H = this.getRenderSize(this.offsetSize).H
      // 设置透视摄像机的长宽比
      this.DEFAULT_CAMERA.aspect = W / H
      // 摄像机的 position 和 target 是自动更新的，而 fov、aspect、near、far 的修改则需要重新计算投影矩阵（projection matrix）
      this.DEFAULT_CAMERA.updateProjectionMatrix()
      // 设置渲染器输出的 canvas 的大小
      this.rederer.setSize(W, H)
    })
  }

  // 全局执行帧动画
  globalRAF () {
    this.Signals.requestAnimationFrame.dispatch()
    requestAnimationFrame(this.globalRAF.bind(this))
  }

  // 全局执行窗口改变
  globalWindowResize () {
    this.Signals.windowResize.dispatch()
  }
}
