import Store from '@/store'
import _collection from 'lodash/collection'
import { SelectAction } from '@/utils/EditorMethods'

const THREE = window.THREE
/**
 * 单机选择事件
 */
export class EditorClick {
  constructor (globalObject) {
    this.clickDown = false
    this.mouse = new THREE.Vector2()
    this.raycaster = new THREE.Raycaster()
    this.onDownPosition = new THREE.Vector2()
    this.onUpPosition = new THREE.Vector2()
    this.dom = globalObject.rederer.domElement
    this.bindPicker(this.dom)
  }

  getMousePosition (dom, x, y) {
    let rect = dom.getBoundingClientRect()
    return [(x - rect.left) / rect.width, (y - rect.top) / rect.height]
  }

  OnMouseDown (event) {
    if (this.clickDown) { return }
    this.clickDown = true
    event.preventDefault()
    let posArr = this.getMousePosition(this.dom, event.clientX, event.clientY)
    this.onDownPosition.fromArray(posArr)
    document.removeEventListener('mouseup', this.onMouseUp.bind(this), false)
    document.addEventListener('mouseup', this.onMouseUp.bind(this), false)
  }

  onMouseUp (event) {
    if (!this.clickDown) { return }
    this.clickDown = false
    let posArr = this.getMousePosition(this.dom, event.clientX, event.clientY)
    this.onUpPosition.fromArray(posArr)
    document.removeEventListener('mouseup', this.onMouseUp.bind(this), false)
    this.handleClick()
  }

  OnTouchStart (event) {
    if (this.clickDown) { return }
    this.clickDown = true
    let touch = event.changedTouches[0]
    let posArr = this.getMousePosition(this.dom, touch.clientX, touch.clientY)
    this.onDownPosition.fromArray(posArr)
    document.addEventListener('touchend', this.OnTouchEnd.bind(this), false)
  }

  OnTouchEnd (event) {
    if (!this.clickDown) { return }
    this.clickDown = false
    let touch = event.changedTouches[0]
    let posArr = this.getMousePosition(this.dom, touch.clientX, touch.clientY)
    this.onUpPosition.fromArray(posArr)
    this.handleClick()
    document.removeEventListener('touchend', this.OnTouchEnd.bind(this), false)
  }

  getIntersects (point, objects) {
    const camera = this.getCamera()
    this.mouse.set((point.x * 2) - 1, -(point.y * 2) + 1)
    this.raycaster.setFromCamera(this.mouse, camera)
    console.log('objects', objects)
    return this.raycaster.intersectObjects(objects, true)
  }

  handleClick () {
    if (this.onDownPosition.distanceTo(this.onUpPosition) === 0) {
      console.log('触发点击')
      let intersects = this.getIntersects(this.onUpPosition, this.getObjects())
      console.log('intersects', intersects)
      if (intersects.length > 0) {
        let object = intersects[ 0 ].object
        console.log('handleClick', object)
        if (object.userData.object !== undefined) {
        } else {
          SelectAction.selectObject(object)
        }
      } else {
        SelectAction.selectObject(null)
      }
    }
  }

  getCamera () {
    return Store.state.globalObject.DEFAULT_CAMERA
  }

  getObjects () {
    let geometrys = _collection.map(Store.state.geometryObjects)
    let lights = _collection.map(Store.state.lightObjects)
    let Objects = geometrys.concat(lights)
    return Objects
  }

  // 绑定点击事件
  bindPicker (El) {
    console.log('绑定点击事件')
    El.addEventListener('mousedown', this.OnMouseDown.bind(this), false)
    El.addEventListener('touchstart', this.OnTouchStart.bind(this), false)
  }
}
