/**
 * 公共函数
 */
export class PubilcMethods {
  /*
  * 创建script 引用文件，解决无法引入包导致的错误
  * 比如：FBX需要inflate import引入无法使用
  * 静态文件放入public中
  * */
  static createScript (link) {
    return new Promise(resolve => {
      let r = document.createElement('script')
      r.type = 'text/javascript'
      r.src = link
      r.onload = () => {
        resolve()
      }
      document.body.appendChild(r)
    })
  }
}
