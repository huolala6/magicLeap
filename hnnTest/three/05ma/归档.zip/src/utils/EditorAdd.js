import { EditorMethods } from './EditorMethods'
const THREE = window.THREE
/**
 * 创建threejs 图形
 * segments 分段数，越大越占内存
 * BufferGeometry 会缓存网格模型，性能要高效点。网格模型生成原理
 * 1、Geometry 生成的模型是这样的 （代码）-> (CUP 进行数据处理，转化成虚拟3D数据) -> (GPU 进行数据组装，转化成像素点，准备渲染) -> 显示器
 * 第二次操作时重复走这些流程。
 * 2、BufferGeometry 生成模型流程 (代码) -> (CUP 进行数据处理，转化成虚拟3D数据) -> (GPU 进行数据组装，转化成像素点，准备渲染) -> (丢入缓存区) -> 显示器
 * 第二次修改时，通过API直接修改缓存区数据，流程就变成了这样
 * (代码) -> (CUP 进行数据处理，转化成虚拟3D数据) -> (修改缓存区数据) -> 显示器
 * 节约了GPU性能的运算性能
 */
export class CreateGeometry {
  /**
   * 创建平面 key Plane
   */
  static Plane (scene, options = {}) {
    let geometry = new THREE.PlaneBufferGeometry(options.width, options.height, options.widthSegments, options.heightSegments)
    let material = new THREE.MeshLambertMaterial({ color: options.material_color, side: THREE.DoubleSide })
    let mesh = new THREE.Mesh(geometry, material)
    mesh.castShadow = true
    console.log('创建平面 Plane', mesh)
    scene.add(mesh)
    EditorMethods.add('geometryObjects', mesh.uuid, mesh)
  }
  /**
   * 创建圆形 key Circle
   */
  static Circle (scene, options = {}) {
    let geometry = new THREE.CircleBufferGeometry(options.radius, options.segments, options.thetaStart, options.thetaLength)
    let material = new THREE.MeshLambertMaterial({ color: options.material_color, side: THREE.DoubleSide })
    let mesh = new THREE.Mesh(geometry, material)
    mesh.castShadow = true
    console.log('创建圆形 Circle', mesh)
    scene.add(mesh)
    EditorMethods.add('geometryObjects', mesh.uuid, mesh)
  }
  /**
   * 创建立体图形 key Box
   */
  static Box (scene, options = {}) {
    let geometry = new THREE.BoxBufferGeometry(options.width, options.height, options.depth, options.widthSegments, options.heightSegments, options.depthSegments)
    let material = new THREE.MeshLambertMaterial({ color: options.material_color })
    let mesh = new THREE.Mesh(geometry, material)
    mesh.castShadow = true
    console.log('创建立体图形 Box', mesh)
    scene.add(mesh)
    EditorMethods.add('geometryObjects', mesh.uuid, mesh)
  }
  /**
   * 创建圆锥 key Cone
   */
  static Cone (scene, options = {}) {
    let geometry = new THREE.ConeBufferGeometry(options.radius, options.height, options.radialSegments, options.heightSegments, options.openEnded, options.thetaStart, options.thetaLength)
    let material = new THREE.MeshLambertMaterial({ color: options.material_color })
    let mesh = new THREE.Mesh(geometry, material)
    mesh.castShadow = true
    console.log('创建圆锥 Cone', mesh)
    scene.add(mesh)
    EditorMethods.add('geometryObjects', mesh.uuid, mesh)
  }
  /**
   * 创建圆柱 key Cylinder
   */
  static Cylinder (scene, options = {}) {
    let geometry = new THREE.CylinderBufferGeometry(options.radiusTop, options.radiusBottom, options.height, options.radialSegments, options.heightSegments, options.openEnded, options.thetaStart, options.thetaLength)
    let material = new THREE.MeshLambertMaterial({ color: options.material_color })
    let mesh = new THREE.Mesh(geometry, material)
    mesh.castShadow = true
    console.log('创建圆柱 Cylinder', mesh)
    scene.add(mesh)
    EditorMethods.add('geometryObjects', mesh.uuid, mesh)
  }
  /**
   * 球体 key Sphere
   */
  static Sphere (scene, options = {}) {
    let geometry = new THREE.SphereBufferGeometry(options.radius, options.widthSegments, options.heightSegments, options.phiStart, options.phiLength, options.thetaStart, options.thetaLength)
    let material = new THREE.MeshLambertMaterial({ color: options.material_color })
    let mesh = new THREE.Mesh(geometry, material)
    mesh.castShadow = true
    console.log('球体 Sphere', mesh)
    scene.add(mesh)
    EditorMethods.add('geometryObjects', mesh.uuid, mesh)
  }
  /**
   * 圆环 key Torus
   */
  static Torus (scene, options = {}) {
    let geometry = new THREE.TorusBufferGeometry(options.radius, options.tube, options.radialSegments, options.tubularSegments, options.arc)
    let material = new THREE.MeshLambertMaterial({ color: options.material_color })
    let mesh = new THREE.Mesh(geometry, material)
    mesh.castShadow = true
    console.log('圆环 Sphere', mesh)
    scene.add(mesh)
    EditorMethods.add('geometryObjects', mesh.uuid, mesh)
  }
  /**
   * 字体 key Text
   */
  static Text (scene, options = {}) {
    let loader = new THREE.FontLoader()
    let url = require('../assets/Fonts/' + options.font_name + '.typeface.json')
    let font = loader.parse(url)
    let geometry = new THREE.TextBufferGeometry(options.default_text, {
      font: font,
      size: options.size,
      height: options.height,
      curveSegments: options.curveSegments,
      bevelEnabled: options.bevelEnabled,
      bevelThickness: options.bevelThickness,
      bevelSize: options.bevelSize,
      bevelSegments: options.bevelSegments
    })
    let material = new THREE.MeshLambertMaterial({ color: options.material_color })
    let mesh = new THREE.Mesh(geometry, material)
    mesh.castShadow = true
    console.log('字体 Text', mesh)
    scene.add(mesh)
    EditorMethods.add('geometryObjects', mesh.uuid, mesh)
  }
}
/*
* 添加灯光
* */
export class CreateLight {
  /**
   * 创建方向灯
   */
  static DirectionalLight (scene, options) {
    let light = new THREE.DirectionalLight(options.color, options.intensity)
    light.position.set(options.x, options.y, options.z)
    light.castShadow = true
    console.log('方向灯创建完成', light)
    scene.add(light)
    light.help_obj = CreateHelper('Directional', scene, light, 50)
    EditorMethods.add('lightObjects', light.uuid, light)
  }
  /**
   * 创建半球灯
   */
  static HemisphereLight (scene, options) {
    let light = new THREE.HemisphereLight(options.skyColor, options.groundColor, options.intensity)
    light.position.set(options.x, options.y, options.z)
    light.castShadow = true
    console.log('半球灯创建完成', light)
    scene.add(light)
    light.help_obj = CreateHelper('Hemisphere', scene, light, 50)
    EditorMethods.add('lightObjects', light.uuid, light)
  }
  /**
   * 创建点光源
   */
  static PointLight (scene, options) {
    let light = new THREE.PointLight(options.color, options.intensity, options.distance, options.decay)
    light.position.set(options.x, options.y, options.z)
    light.castShadow = true
    console.log('创建点光源', light)
    scene.add(light)
    light.help_obj = CreateHelper('Point', scene, light, 50)
    EditorMethods.add('lightObjects', light.uuid, light)
  }
  /**
   * 创建聚光灯
   */
  static SpotLight (scene, options) {
    let light = new THREE.SpotLight(options.color, options.intensity, options.distance, options.angle, options.penumbra, options.decay)
    light.position.set(options.x, options.y, options.z)
    light.castShadow = true
    console.log('创建聚光灯', light)
    scene.add(light)
    light.help_obj = CreateHelper('Spot', scene, light, options.color)
    EditorMethods.add('lightObjects', light.uuid, light)
  }
}

/*
 * 添加辅助工具
 * */
function CreateHelper (name, scene, light, options) {
  let helper = new THREE[name + 'LightHelper'](light, options)
  scene.add(helper)
  return helper
}
