import Store from '@/store'
import { EditorMethods } from './EditorMethods'
const THREE = window.THREE
/**
 * 模型文件的操作
 * 支持类型: [DAE, FBX, BLENDER, OBJ, BABYLON, ASSIMP, VRML, STL, PLY, GLTF]
 * TODO 模型自动适应屏幕
 * TODO 可选择同时加载几个模型
 * TODO 大量模型测试后，看函数是否需要更改
 */
export class ModelMethods {
  /*
   * GLTF
   * */
  static GLTF (info) {
    const GLTFLoader = require('@/three/Loaders/GLTFLoader').default
    let loader = new GLTFLoader()
    console.log('(info.filePath', info.filePath)
    loader.load(info.filePath, gltf => {
      console.log('加载的gltf数据', gltf)
      addToScene(gltf.scene).then(() => {
        startAnimation(gltf.scene, gltf.animations)
        addToStore(gltf, 'scene', info.title)
      })
    }, OnProgress)
  }
  /*
  * dae
  * */
  static DAE (info) {
    const ColladaLoader = require('@/three/Loaders/ColladaLoader').default
    const Loader = new ColladaLoader()
    Loader.load(info.filePath, (data) => {
      console.log('data', data)
      let modelScene = data.scene
      // 设置投影
      setChildShadow(modelScene)
      addToScene(modelScene).then(() => {
        startAnimation(modelScene, data.animations)
        addToStore(data, 'scene', info.title)
      })
    }, OnProgress)
  }

  /*
  * fbx
  * */
  static FBX (info) {
    const FBXLoader = require('@/three/Loaders/FBXLoader').default
    const loader = new FBXLoader()
    loader.load(info.filePath, data => {
      setChildShadow(data)
      addToScene(data).then(() => {
        startAnimation(data, data.animations)
        addToStore(data, false, info.title)
      })
    }, OnProgress)
  }

  /*
  * Blender
  * */
  static BLENDER (info) {
    let loader = new THREE.ObjectLoader()
    loader.load(info.filePath, obj => {
      addToScene(obj).then(() => {
        startAnimation(obj, obj.animations)
        addToStore(obj, false, info.title)
      })
    }, OnProgress)
  }

  /*
  * obj
  * 分为三种情况
  * // TODO 有mtl也有图片的，写setPath会报错
  * 1.有mtl文件,2.没有mtl 有图片的（仅限制一张）3.没有mtl 也没有图片的
  * */
  static OBJ (info) {
    const OBJLoader = require('@/three/Loaders/OBJLoader').default
    const objLoader = new OBJLoader()
    if (info.mtlFile) {
      const MTLLoader = require('@/three/Loaders/MTLLoader').default
      const mtlLoader = new MTLLoader()
      mtlLoader.load(info.mtlFile, material => {
        objLoader.setMaterials(material)
        objLoader.load(info.objFile, object => {
          addToScene(object).then(() => {
            addToStore(object, false, info.title)
          })
        }, OnProgress)
      }, OnProgress)
    } else if (info.objFile && info.objTexture) {
      objLoader.load(info.objFile, object => {
        let textureLoader = new THREE.TextureLoader()
        let texture = textureLoader.load(info.objTexture)
        object.traverse(function (child) {
          if (child.isMesh) child.material.map = texture
        })
        addToScene(object).then(() => {
          addToStore(object, false, info.title)
        })
      }, OnProgress)
    } else if (info.objFile && info.modelColor) {
      objLoader.load(info.objFile, object => {
        let material = new THREE.MeshLambertMaterial({ color: info.modelColor })
        object.children.forEach(function (child) {
          child.material = material
          child.geometry.computeFaceNormals()
          child.geometry.computeVertexNormals()
        })
        addToScene(object).then(() => {
          addToStore(object, false, info.title)
        })
      }, OnProgress)
    }
  }

  /*
  * babylon
  * */
  static BABYLON (info) {
    const BabylonLoader = require('@/three/Loaders/BabylonLoader').default
    let loader = new BabylonLoader()
    loader.load(info.filePath, obj => {
      obj.traverse(object => {
        if (object instanceof THREE.Mesh) {
          object.material = new THREE.MeshPhongMaterial({
            color: info.modelColor
          })
        }
      })
      addToScene(obj).then(() => {
        addToStore(obj, false, info.title)
      })
    }, OnProgress)
  }

  /*
   * ASSIMP
   * */
  static ASSIMP (info) {
    const AssimpLoader = require('@/three/Loaders/AssimpLoader').default
    let loader = new AssimpLoader()
    loader.load(info.filePath, result => {
      addToScene(result.object).then(() => {
        addToStore(result, 'object', info.title)
      })
      const performance = window.performance || window.msPerformance || window.webkitPerformance
      Store.state.globalObject.Signals.requestAnimationFrame.add(() => {
        result.animation.setTime(performance.now() / 1000)
      }, { uuid: result.object.uuid })
    }, OnProgress)
  }

  /*
  * VRML
  * */
  static VRML (info) {
    const VRMLLoader = require('@/three/Loaders/VRMLLoader').default
    let loader = new VRMLLoader()
    loader.load(info.filePath, obj => {
      addToScene(obj).then(() => {
        addToStore(obj, false, info.title)
      })
    }, OnProgress)
  }

  /*
   * stl
   * */
  static STL (info) {
    const STLLoader = require('@/three/Loaders/STLLoader').default
    let loader = new STLLoader()
    loader.load(info.filePath, geometry => {
      // 创建纹理
      let mat = new THREE.MeshLambertMaterial({ color: info.modelColor })
      let mesh = new THREE.Mesh(geometry, mat)
      geometry.center()
      addToScene(mesh).then(() => {
        addToStore(mesh, false, info.title)
      })
    }, OnProgress)
  }

  /*
   * PLY
   * */
  static PLY (info) {
    const PLYLoader = require('@/three/Loaders/PLYLoader').default
    let loader = new PLYLoader()
    loader.load(info.filePath, geometry => {
      // 更新顶点的法向量
      geometry.computeVertexNormals()
      // 创建纹理
      let mat = new THREE.MeshStandardMaterial({ color: info.modelColor, flatShading: true })
      let mesh = new THREE.Mesh(geometry, mat)
      addToScene(mesh).then(() => {
        addToStore(mesh, false, info.title)
      })
    }, OnProgress)
  }
}

/*
* 模型动画的处理
* */
export class ModelAnimate {
  /*
  * 删除模型在渲染中的更新
  * */
  static removeTimer (uuid) {
    return new Promise(resolve => {
      let requestAnimationFrame = Store.state.globalObject.Signals.requestAnimationFrame
      let _bindings = requestAnimationFrame._bindings
      for (let i = 0; i < _bindings.length; i++) {
        if (_bindings[i].context && _bindings[i].context.uuid) {
          if (_bindings[i].context.uuid === uuid) {
            _bindings[i]._destroy()
            _bindings.splice(i, 1)
            resolve()
            break
          }
        }
      }
    })
  }
  /*
  * 添加动画到定时渲染中
  * */
  static addTimer (uuid, mixer, speed = 1) {
    const clock = new THREE.Clock()
    let requestAnimationFrame = Store.state.globalObject.Signals.requestAnimationFrame
    requestAnimationFrame.add(() => {
      let time = clock.getDelta()
      mixer.update(time * speed)
    }, { uuid: uuid })
  }
}

/*
* 添加到场景中
* */
function addToScene (obj) {
  return new Promise(resolve => {
    let scene = Store.state.globalObject.DEFAULT_SCENE
    let ModelObjects = Store.state.ModelObjects
    // 如果仅仅可以加一个，则直接替换
    if (Store.state.JustOneModel && Object.keys(ModelObjects).length) {
      // 删除上一个
      EditorMethods.remove('ModelObjects', Object.keys(ModelObjects)[0])
    }
    scene.add(obj)
    adaptScene(obj)
    resolve()
    loadSuccess()
  })
}

/*
* 设置child 投影
* */
function setChildShadow (data) {
  data.traverse((child) => {
    if (child.isMesh) {
      child.castShadow = true
      child.receiveShadow = true
    }
  })
}

/*
* 初始播放动画
* */
function startAnimation (data, animations, index = 0) {
  let mixer = data.mixer = new THREE.AnimationMixer(data)
  if (animations[index]) {
    let action = mixer.clipAction(animations[index])
    action.play()
  }
  ModelAnimate.addTimer(data.uuid, mixer)
}

/*
* 进度
* */
function OnProgress (progress) {
  console.log('progress', progress)
}

/*
* 加载完成
* */
function loadSuccess () {
  console.log('加载完成')
}

/*
* 添加到数据中
* */
function addToStore (data, objName, title) {
  console.log('模型添加成功', data)
  data._model_info_title = title
  data._model_obj_name = objName
  let uuid = objName ? data[objName].uuid : data.uuid
  EditorMethods.add('ModelObjects', uuid, data)
}

/**
 * 模型适应场景
 */
function adaptScene (obj) {
  console.log('obj', obj)
  // let meshHelper = new THREE.BoxHelper(obj, 0xffff00)
  // meshHelper.geometry.computeBoundingBox()
  // console.log('meshHelper.geometry.boundingBox', meshHelper.geometry.boundingBox)
  // console.log('meshHelper.geometry.boundingSphere', meshHelper.geometry.boundingSphere)
  // if (meshHelper.geometry.boundingSphere) {
  //   Store.state.globalObject.DEFAULT_SCENE.add(meshHelper)
  //   let center = meshHelper.geometry.boundingSphere.center
  //   let radius = meshHelper.geometry.boundingSphere.radius
  //   let cameraPos = new THREE.Vector3(center.x + obj.position.x, center.y + obj.position.y, radius * 4.9 + center.z + obj.position.z)
  //   Store.state.globalObject.DEFAULT_CAMERA.position.set(cameraPos.x, cameraPos.y, cameraPos.z)
  // }
}
