import Store from '@/store'
const THREE = window.THREE
/**
 * 属性的设置
 */
export class SetProperty {
  /*
   * 设置无背景
   * */
  static setClearBg () {
    Store.state.globalObject.DEFAULT_SCENE.background = null
    removeBackground()
  }
  /*
   * 通过颜色设置背景
   * 如果已经实例化Color，那么直接设置，没有则需要先实例化
   * */
  static setBgByColor (hex) {
    removeBackground()
    let bg = Store.state.globalObject.DEFAULT_SCENE.background
    if (bg instanceof THREE.Color) {
      bg.setStyle(hex)
    } else {
      Store.state.globalObject.DEFAULT_SCENE.background = new THREE.Color(hex)
    }
  }
  /*
   * 通过背景图设置背景
   * */
  static setBgByTexture (imgLink) {
    removeBackground()
    let loader = new THREE.TextureLoader()
    loader.load(imgLink, (texture) => {
      Store.state.globalObject.DEFAULT_SCENE.background = texture
    })
  }
  /*
   * 通过环境图设置背景
   * 分为两种，一张图的，直接用圆几何，六张图的用盒几何
   * 在更改前，判断material和geometry，再更改
   * */
  static setBgByGeometry (item) {
    console.log('通过环境图设置背景', item)
    let globalObject = Store.state.globalObject
    globalObject.DEFAULT_SCENE.background = null
    if (!item.resource) {
      let geometry = new THREE.SphereBufferGeometry(4000, 100, 100)
      geometry.scale(-1, 1, 1)
      let loader = new THREE.TextureLoader()
      loader.load(item.cover, texture => {
        let material = new THREE.MeshBasicMaterial({
          map: texture
        })
        if (!globalObject.SCENE_BACKGROUND) {
          globalObject.SCENE_BACKGROUND = new THREE.Mesh(geometry, material)
          globalObject.DEFAULT_SCENE.add(globalObject.SCENE_BACKGROUND)
        } else {
          globalObject.SCENE_BACKGROUND.geometry = geometry
          globalObject.SCENE_BACKGROUND.material = material
        }
        Store.commit('setStateData', { name: 'globalObject', value: globalObject })
      })
    } else {
      let geometry = new THREE.BoxBufferGeometry(4000, 4000, 4000, 7, 7, 7)
      geometry.scale(-1, 1, 1)
      let materials = []
      for (let i = 0; i < item.resource.length; i++) {
        let loader = new THREE.TextureLoader()
        let texture = loader.load(item.resource[i])
        texture.needsUpdate = true
        let material = new THREE.MeshBasicMaterial({
          map: texture,
          overdraw: 0.5
        })
        materials.push(material)
        console.log(i, item.resource.length - 1)
        if (i === item.resource.length - 1) {
          console.log('materials', materials)
          if (!globalObject.SCENE_BACKGROUND) {
            globalObject.SCENE_BACKGROUND = new THREE.Mesh(geometry, materials)
            globalObject.DEFAULT_SCENE.add(globalObject.SCENE_BACKGROUND)
          } else {
            globalObject.SCENE_BACKGROUND.geometry = geometry
            globalObject.SCENE_BACKGROUND.material = materials
          }
          Store.commit('setStateData', { name: 'globalObject', value: globalObject })
        }
      }
    }
  }
  /*
   * 设置全景背景的方向
   * */
  static setBgOrientation (val) {
    let globalObject = Store.state.globalObject
    if (globalObject.SCENE_BACKGROUND) {
      globalObject.SCENE_BACKGROUND.rotation.y = val * Math.PI * 2
    }
  }
  /*
   * 设置相机远近
   * */
  static setCameraField (val) {
    let camera = Store.state.globalObject.DEFAULT_CAMERA
    camera.fov = val
    camera.updateProjectionMatrix()
  }
}

/*
 * 删除背景mesh
 * */
function removeBackground () {
  let globalObject = Store.state.globalObject
  if (globalObject.SCENE_BACKGROUND) {
    globalObject.DEFAULT_SCENE.remove(globalObject.SCENE_BACKGROUND)
    delete globalObject.SCENE_BACKGROUND
    Store.commit('setStateData', { name: 'globalObject', value: globalObject })
  }
}
