import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    JustOneModel: true, // 是否只能显示一个模型
    globalObject: {},
    geometryObjects: {},
    CurrentObject: {},
    ModelObjects: {},
    coverageList: [],
    lightObjects: {}
  },
  mutations: {
    setStateData (state, info) {
      state[info.name] = info.value
    }
  },
  actions: {
    setStateData (setStateData) {
      setStateData.commit('setStateData')
    }
  },
  getters: {
    JustOneModel (state) { return state.JustOneModel },
    globalObject (state) { return state.globalObject },
    lightObjects (state) { return state.lightObjects },
    CurrentObject (state) { return state.CurrentObject },
    coverageList (state) { return state.coverageList },
    ModelObjects (state) { return state.ModelObjects },
    geometryObjects (state) { return state.geometryObjects }
  }
})
