/**
 * 服务器请求接口 API
 * @base 基础配置
 * @config 额外配置及说明
 * @config 请求的接口
 */
export default {
  base: {
    protocol: 'http://',
    host: 'snail.shv.im',
    port: 80,
    basePath: '/api/'
  },
  config: {
    token_basic: '',
    timeout: 60000,
    token_lose_code: 401
  },
  postName: {
    configs: 'configs'
  }
}
