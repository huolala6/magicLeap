
import API from './Api'
import axios from 'axios'
import qs from 'qs'

// 接收接口请求的promise数组
let promises = []
// loading的定时器
let loadingTimer = []
let baseURL = API.base.protocol + API.base.host + ':' + API.base.port + API.base.basePath + '/'

// 处理path
const getPath = (_url, path) => {
  let pathKeys = Object.keys(path)
  if (pathKeys.length) {
    for (let i = 0; i < pathKeys.length; i++) {
      let key = pathKeys[i]
      _url = _url.replace('{' + key + '}', path[key])
    }
  }
  return _url
}

// loading 等待函数
const requestLoading = {
  time: 200,
  start () {
    console.log('loading start')
  },
  stop () {
    console.log('loading stop')
  }
}

// toast 提示函数
const requestToast = (err) => {
  if (err && err.msg) {
    console.log('toast open', err.msg)
  }
}

/*
* Promise request
* @param url type String postName中接口对应的名称
* @param Info type Object 为请求数据集合
* @return Promise实例
* */
export const handleRequest = (url = '', Info = {}) => {
  let {
    body = {},
    bodyIsStr = true,
    query = {},
    type = 'post', path = {} } = Info
  let _url = API.postName[url]
  let resetUrl = Info.baseURL || baseURL
  // 处理path
  _url = getPath(_url, path)
  // 配置token
  /* if (headers.Authorization) {
    headers.Authorization = API.config.token_basic + ' ' + headers.Authorization
  } */
  let request = axios({
    method: type,
    data: bodyIsStr ? qs.stringify(body) : body,
    baseURL: resetUrl,
    timeout: API.config.timeout,
    params: query,
    headers: {},
    url: _url
  })
  clearTimeout(loadingTimer)
  loadingTimer = setTimeout(() => {
    requestLoading.start()
  }, requestLoading.time)
  // 计算当前的promise是否全部加载完成
  promises.push(request.catch(e => {}))
  Promise.all(promises).then(data => {
    if (data.length !== promises.length) return
    promises = [] // 所有请求完后清除promise数组
    clearTimeout(loadingTimer) // 当请求在xxxms内完成则直接清除loading计时器
  }).catch(() => {
    requestLoading.stop()
    promises = [] // 请求异常完后清除promise数组
    clearTimeout(loadingTimer) // 请求异常则直接清除loading计时器
  })
  return request.then(suc => {
    console.log(url + ' API请求 请求成功', suc)
    return suc.data
  }).catch((err) => {
    console.log(url + ' API请求 请求失败', err)
    if (err && err.response) {
      requestToast(err.response)
    }
  })
}

export default {
  install (Vue) {
    Vue.prototype.$Request = handleRequest
  }
}
