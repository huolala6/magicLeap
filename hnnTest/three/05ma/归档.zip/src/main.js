import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import * as THREE from 'three'
import fontIcon from '@/components/Icon'
import 'material-design-icons-iconfont/dist/material-design-icons.css'
import Vuetify from 'vuetify'
import 'vuetify/dist/vuetify.min.css'

Vue.use(Vuetify)
Vue.component('font-icon', fontIcon)
window.THREE = THREE

Vue.config.productionTip = false

new Vue({
  router,
  store,
  render: h => h(App),
  created () {
    window.EditorPublic = this
  }
}).$mount('#app')

// 开发控制台
/* if (process.env.NODE_ENV === 'development') {
  (function () {
    var script = document.createElement('script')
    script.src = '//cdn.jsdelivr.net/npm/eruda'
    document.body.appendChild(script)
    script.onload = function () { window.eruda.init() }
  })()
} */
