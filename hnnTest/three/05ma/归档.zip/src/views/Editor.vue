<template>
  <div class="Editor" id="Editor">
    <PropertyPanel v-if="loaded"></PropertyPanel>
    <v-btn fixed dark fab top left color="light-green" class="Editor_upload_btn" @click.native="showUpload = true">
      <font-icon name="shangchuan"></font-icon>
    </v-btn>
    <uploadModel v-if="showUpload" @closeUpload="showUpload = false"></uploadModel>
  </div>
</template>

<script>
import PropertyPanel from '@/templates/PropertyPanel'
import uploadModel from '@/templates/uploadModel'
import { BasicInitEditor } from '@/utils/BasicInitEditor'
import { PubilcMethods } from '@/utils/PubilcMethods'
export default {
  name: 'Editor',
  components: { PropertyPanel, uploadModel },
  data () {
    return {
      loaded: false,
      showUpload: false
    }
  },
  methods: {
  },
  mounted () {
    this.$nextTick(() => {
      let inflate = PubilcMethods.createScript('static/Libs/inflate.min.js')
      Promise.all([inflate]).then(() => {
        let globalObject = new BasicInitEditor(document.getElementById('Editor'), {
          left: 300
        })
        this.$store.commit('setStateData', { name: 'globalObject', value: globalObject })
        window.addEventListener('resize', globalObject.globalWindowResize.bind(globalObject), false)
        this.loaded = true
      })
    })
  }
}
</script>
<style lang="less">
@import '../Less/base';
.Editor{
  width: 100%;
  height: 100%;
  position: relative;
  background: url("../assets/5a712a2a84bec.png") no-repeat center;
  background-size: cover;
  .Editor_upload_btn{
    left: 316px;
  }
  canvas{
    position: absolute;
    right:0;
  }
}
</style>
