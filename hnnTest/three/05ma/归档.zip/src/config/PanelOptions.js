/**
 * 属性面板的配置
 */
export const PanelUI = {
  menus: [
    { key: 'add', icon: 'plus', tip: '添加' },
    { key: 'model', icon: 'moxing', tip: '模型' },
    { key: 'coverage', icon: 'tongbujichengshuxing', tip: '图层和属性' },
    { key: 'animation', icon: 'donghua', tip: '动画' },
    { key: 'setting', icon: 'icon-test', tip: '设置' }
  ],
  animation: {
    Types: [{ type: 'single', icon: 'danquxunhuan' }, { type: 'circle', icon: 'Artboard' }, { type: 'order', icon: 'shunxubofang' }], // 播放方式
    Speeds: [{ type: 'x0.1', val: 0.1 }, { type: 'x0.5', val: 0.5 }, { type: 'x1.0', val: 1.0 }, { type: 'x2.0', val: 2.0 }] // 播放速度
  },
  camera: {
    name: '相机视野远近',
    field: 45,
    min: 0,
    max: 179
  },
  background: {
    name: '背景',
    isOpen: true,
    Orientation: 0,
    Orientation_max: 360,
    brightness: 2,
    brightness_max: 35,
    currentType: 'color',
    menus: [
      { value: 'color', text: '颜色' },
      { value: 'images', text: '背景图' },
      { value: 'environments', text: '环境' }
    ],
    color: '#cccccc',
    images: [
      { name: 'BLACK1', src: 'http://static.shv.im/XR/backgrounds/6250d36a03f640768db171988fef93d8.jpeg' },
      { name: 'BLACK2', src: 'http://static.shv.im/XR/backgrounds/c83e0d6cbeb34c18b39622647d5bd2ab.jpeg' },
      { name: 'BLACK3', src: 'http://static.shv.im/XR/backgrounds/1f02ba0b83464d6f89a61c6652849413.jpeg' },
      { name: 'BLACK4', src: 'http://static.shv.im/XR/backgrounds/3e08150630f042eaa86f19591a13a1ef.jpeg' }
    ],
    environments: [
      { name: '环境1', cover: 'http://static.shv.im/XR/environments/background.jpg' },
      { name: '环境1',
        cover: 'http://static.shv.im/XR/environments/sky/CD096EA4-A4D4-407B-8542-2F569231569C.png',
        resource: [
          'http://static.shv.im/XR/environments/sky/px.jpg',
          'http://static.shv.im/XR/environments/sky/nx.jpg',
          'http://static.shv.im/XR/environments/sky/py.jpg',
          'http://static.shv.im/XR/environments/sky/ny.jpg',
          'http://static.shv.im/XR/environments/sky/pz.jpg',
          'http://static.shv.im/XR/environments/sky/nz.jpg'
        ] },
      { name: '环境1',
        cover: 'http://static.shv.im/XR/environments/street/00A5A376-6D4F-4247-893E-D189D7298B46.png',
        resource: [
          'http://static.shv.im/XR/environments/street/panorama.right.jpg',
          'http://static.shv.im/XR/environments/street/panorama.left.jpg',
          'http://static.shv.im/XR/environments/street/panorama.top.jpg',
          'http://static.shv.im/XR/environments/street/panorama.bottom.jpg',
          'http://static.shv.im/XR/environments/street/panorama.front.jpg',
          'http://static.shv.im/XR/environments/street/panorama.back.jpg'
        ] },
      { name: '环境1',
        cover: 'http://static.shv.im/XR/environments/street/3F24DC43-C9C2-492B-A384-4C7C5E505D69.png',
        resource: [
          'http://static.shv.im/XR/environments/bal/over_the_clouds.right.jpg',
          'http://static.shv.im/XR/environments/bal/over_the_clouds.left.jpg',
          'http://static.shv.im/XR/environments/bal/over_the_clouds.top.jpg',
          'http://static.shv.im/XR/environments/bal/over_the_clouds.bottom.jpg',
          'http://static.shv.im/XR/environments/bal/over_the_clouds.front.jpg',
          'http://static.shv.im/XR/environments/bal/over_the_clouds.back.jpg'
        ] }
    ]
  }
}
