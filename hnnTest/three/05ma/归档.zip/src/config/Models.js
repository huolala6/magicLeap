/**
 * 3D模型
 */
export const Models = [
  {
    filePath: 'http://static.shv.im/XR/models/fbx/shimoxi-baozha.fbx',
    type: 'fbx',
    title: 'shimoxi-baozha',
    cover: 'https://img.delvenetworks.com/gdX9KjCLT1wmBYosX6fyt0/4Cze6tozRgkrRFt7ZlZg1k/fOh.540x302.jpeg'
  },
  {
    filePath: 'http://static.shv.im/XR/models/gltf/na_cl/na_cl.gltf',
    type: 'GLTF',
    title: 'na_cl',
    cover: 'http://img02.tooopen.com/images/20160509/tooopen_sy_161967094653.jpg'
  },
  {
    filePath: 'http://static.shv.im/XR/models/gltf/DamagedHelmet/DamagedHelmet.gltf',
    type: 'GLTF',
    title: 'DamagedHelmet',
    cover: 'http://himg2.huanqiu.com/attachment2010/2015/1027/20151027100009304.jpg'
  },
  {
    filePath: 'http://static.shv.im/XR/models/dae/stormtrooper/stormtrooper.dae',
    type: 'dae',
    title: 'Stormtrooper',
    cover: 'http://desktopwallpapers.org.ua/large/201111/8037.jpg'
  },
  {
    filePath: 'http://static.shv.im/XR/models/fbx/Naruto.fbx',
    type: 'fbx',
    title: 'Naruto',
    cover: 'https://vignette.wikia.nocookie.net/naruto/images/0/09/Naruto_newshot.png/revision/latest?cb=20170621101134'
  },
  {
    filePath: 'http://static.shv.im/XR/models/blender/misc_chair01.json',
    type: 'BLENDER',
    title: 'chair',
    cover: 'http://img01.jituwang.com/170422/256986-1F42210303699.jpg'
  },
  // {
  //   objFile: 'https://www.banggemang.com/Models/OBJ/butterfly.obj',
  //   mtlFile: 'https://www.banggemang.com/Models/OBJ/butterfly.mtl',
  //   objTexture: 'https://www.banggemang.com/Models/OBJ/butterflywings.png',
  //   type: 'OBJ',
  //   title: 'butterfly',
  //   cover: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSq7iCG8hQ1iCqp7fqhnMfnayJqo5xFOzuYqurz0XzQEd_nwRDeww'
  // },
  {
    filePath: 'http://static.shv.im/XR/models/babylon/skull.babylon',
    modelColor: 0xe16b8c,
    type: 'babylon',
    title: 'skull',
    cover: 'http://3.bp.blogspot.com/-KgchHk6WecA/V8pWWpZQ1jI/AAAAAAAAhNY/9DSTNjX53L0dwnkHFq9iTEEKGMPuzZDbgCHM/s1600/terminator-salvation-game-wallpapers.jpg'
  },
  {
    objFile: 'http://static.shv.im/XR/models/obj/pinecone.obj',
    modelColor: 0x5C3A21,
    type: 'OBJ',
    title: 'pinecone',
    cover: 'https://www.broogly.com/photo/476/pine-cone-owl.jpg?type=large'
  },
  {
    filePath: 'http://static.shv.im/XR/models/assimp/Octaminator/Octaminator.assimp',
    type: 'ASSIMP',
    title: 'Octaminator',
    cover: 'http://photo.l99.com/bigger/20/1310651676410_76tfru.jpg'
  },
  {
    filePath: 'http://static.shv.im/XR/models/wrl/house.wrl',
    type: 'VRML',
    title: 'house',
    cover: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQUSgMBaf2591cZLX_o4MTCt6M5ejCeJABcr1naINZp-MMv9IvN'
  },
  {
    filePath: 'http://static.shv.im/XR/models/stl/SolidHead_2_lowPoly_42k.stl',
    type: 'stl',
    modelColor: 0xe16b8c,
    title: 'SolidHead_2_lowPoly_42k',
    cover: 'https://cbu01.alicdn.com/img/ibank/2017/843/163/5273361348_509990420.400x400.jpg'
  },
  {
    filePath: 'http://static.shv.im/XR/models/ply/Lucy100k.ply',
    type: 'ply',
    modelColor: 0xe16b8c,
    title: 'Lucy100k',
    cover: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQLEZGflFO1MQlVC1OvW_NPU-ouXaSvMCIC1iJMv5FNEbOLzjkN'
  },
  {
    objFile: 'http://static.shv.im/XR/models/obj/male/male02.obj',
    objTexture: 'https://threejs.org/examples/textures/UV_Grid_Sm.jpg',
    type: 'OBJ',
    title: 'male02',
    cover: 'http://i1.bangqu.com/r2/news/20171228/30493039595070394e6a.jpg'
  },
  {
    filePath: 'http://static.shv.im/XR/models/fbx/SambaDancing.fbx',
    type: 'fbx',
    title: 'Dancing',
    cover: 'http://showbiz-news.org/wp-content/uploads/2015/04/04_YouTube_ExMachina-141030-e1428662365407.jpg'
  }
]
