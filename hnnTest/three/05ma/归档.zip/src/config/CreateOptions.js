export const CreateOptions = {
  two_geometry: {
    name: '2D',
    options: [
      {
        key: 'Plane',
        icon: 'rect',
        name: '平面',
        options: {
          width: 100,
          height: 100,
          widthSegments: 2,
          heightSegments: 2,
          material_color: 0xf19483
        }
      },
      { key: 'Circle',
        name: '圆形',
        icon: 'circle',
        options: {
          radius: 50,
          segments: 32,
          thetaStart: 0,
          thetaLength: 2 * Math.PI,
          material_color: 0xf19483
        }
      },
      { key: 'Text',
        name: '字体',
        icon: 'text',
        options: {
          font_name: 'gentilis_regular',
          default_text: 'Hello',
          size: 100,
          height: 20,
          curveSegments: 12,
          bevelEnabled: true,
          bevelThickness: 2,
          bevelSize: 2,
          bevelSegments: 2,
          material_color: 0xf19483
        }
      }
    ]
  },
  three_geometry: {
    name: '3D',
    options: [
      { key: 'Box',
        name: '立体图形',
        icon: 'box',
        options: {
          width: 100,
          height: 100,
          depth: 100,
          widthSegments: 1,
          heightSegments: 1,
          depthSegments: 1,
          material_color: 0xf19483
        } },
      { key: 'Cone',
        name: '圆锥',
        icon: 'xuniyuanzhuiti',
        options: {
          radius: 50,
          height: 200,
          radialSegments: 32,
          heightSegments: 2,
          openEnded: false,
          thetaStart: 0,
          thetaLength: 2 * Math.PI,
          material_color: 0x000000
        } },
      { key: 'Cylinder',
        name: '圆柱',
        icon: 'yuanzhuticopy',
        options: {
          radiusTop: 50,
          radiusBottom: 50,
          height: 100,
          radialSegments: 32,
          heightSegments: 1,
          openEnded: false,
          thetaStart: 0,
          thetaLength: 2 * Math.PI,
          material_color: 0xf19483
        } },
      { key: 'Sphere',
        name: '球体',
        icon: 'qiuti',
        options: {
          radius: 50,
          widthSegments: 32,
          heightSegments: 32,
          phiStart: 0,
          phiLength: 2 * Math.PI,
          thetaStart: 0,
          thetaLength: 2 * Math.PI,
          material_color: 0xf19483
        } },
      { key: 'Torus',
        name: '圆环',
        icon: 'yuanhuan',
        options: {
          radius: 50,
          tube: 20,
          radialSegments: 32,
          tubularSegments: 32,
          arc: 2 * Math.PI,
          material_color: 0xf19483
        } }
    ]
  },
  lights: {
    name: '灯光',
    options: [
      { key: 'DirectionalLight',
        name: '方向灯',
        options: {
          color: 0xffffff,
          intensity: 1,
          x: 100,
          y: 100,
          z: 100
        } },
      { key: 'HemisphereLight',
        name: '半球灯',
        options: {
          skyColor: 0xffffbb,
          groundColor: 0xffffff,
          intensity: 1,
          x: 100,
          y: 100,
          z: 100
        } },
      { key: 'PointLight',
        name: '点光源',
        options: {
          color: 0xffffff,
          intensity: 1,
          distance: 0,
          decay: 1,
          x: 100,
          y: 100,
          z: 100
        } },
      { key: 'SpotLight',
        name: '聚光灯',
        options: {
          color: 0xffffff,
          intensity: 1,
          distance: 0,
          angle: 1.5 * Math.PI,
          penumbra: 0,
          decay: 1,
          x: 100,
          y: 100,
          z: 100
        } }
    ]
  }
}
