<template>
    <div class="PanelAnimation px-2">
        <v-flex xs12 class="mb-2" v-if="model.animations && model.animations.length">
            <v-subheader class="px-0">播放方式</v-subheader>
            <v-btn-toggle v-model="playType" @change="autoPlayEvent" mandatory class="light-green v-btn--block ma-0 elevation-0" dark>
                <v-btn block v-for="(item,index) in options.Types" :key="index" color="transparent">
                    <font-icon :name="item.icon"></font-icon>
                </v-btn>
            </v-btn-toggle>
        </v-flex>
        <v-flex xs12 v-if="model.animations && model.animations.length">
            <v-subheader class="px-0">播放速度</v-subheader>
            <v-btn-toggle v-model="playSpeed" @change="setPlaySpeed" mandatory class="light-green v-btn--block ma-0 elevation-0" dark>
                <v-btn block v-for="(item,index) in options.Speeds" :key="index" color="transparent">
                    <span v-text="item.type"></span>
                </v-btn>
            </v-btn-toggle>
        </v-flex>
        <v-flex xs12 v-if="model.animations && model.animations.length">
            <v-subheader class="px-0">动画列表</v-subheader>
            <v-btn block @click="stopAnimate" color="grey darken-4" dark class="mb-3">静止</v-btn>
            <v-divider></v-divider>
            <v-btn block dark
                   class="elevation-0"
                   :class="{'elevation-3': currentIndex === index && !stop}"
                   :color="currentIndex === index && !stop?'amber darken-1':'grey darken-2'"
                   v-for="(item,index) in model.animations"
                   :key="index"
                   @click="startAnimate(item, index)">
                <span v-text="item.name"></span>
                <v-spacer></v-spacer>
                <small v-text="item.duration.toFixed(1)+'秒'"></small>
            </v-btn>
        </v-flex>
    </div>
</template>

<script>
import { PanelUI } from '@/config/PanelOptions'
import { ModelAnimate } from '@/utils/ModelMethods'
export default{
  props: {},
  components: {},
  created () {
    this.options = PanelUI.animation
  },
  data () {
    return {
      options: {},
      currentIndex: 0,
      stop: false,
      playType: 0,
      playTimer: null,
      playSpeed: 2
    }
  },
  computed: {
    model () {
      let currentObject = this.$store.state.CurrentObject
      let ModelObjects = this.$store.state.ModelObjects
      let keys = Object.keys(ModelObjects)
      if (!keys.length) { return {} }
      let model = {}
      if (currentObject && currentObject.uuid) {
        model = this.$store.state.ModelObjects[currentObject.uuid]
      }
      if (!model || !Object.keys(model).length) {
        model = this.$store.state.ModelObjects[keys[0]]
      }
      if (!model) { return {} }
      return model
    }
  },
  methods: {
    /*
    * 停止播放
    * */
    stopAnimate () {
      if (this.stop) { return }
      let mixer = this.model.mixer
      if (this.model._model_obj_name) {
        mixer = this.model[this.model._model_obj_name].mixer
      }
      let action = mixer.clipAction(this.model.animations[this.currentIndex])
      action.stop()
      this.stop = true
      clearTimeout(this.playTimer)
    },
    /*
    * 开始播放
    * */
    startAnimate (item, index) {
      this.stopAnimate()
      this.stop = false
      this.currentIndex = index
      let mixer = this.model.mixer
      if (this.model._model_obj_name) {
        mixer = this.model[this.model._model_obj_name].mixer
      }
      let action = mixer.clipAction(item)
      action.play()
      this.autoPlayEvent()
    },
    /*
    * 根据播放方式进行播放
    * */
    autoPlayEvent () {
      clearTimeout(this.playTimer)
      let animations = this.model.animations
      let item = animations[this.currentIndex]
      this.playTimer = setTimeout(() => {
        let nextIndex = this.currentIndex
        if (this.playType !== 0) {
          nextIndex = this.currentIndex + 1
        }
        if (nextIndex >= animations.length) {
          if (this.playType === 1) {
            nextIndex = 0
          }
          if (this.playType === 2) {
            this.stopAnimate()
            return
          }
        }
        this.startAnimate(animations[nextIndex], nextIndex)
      }, item.duration * 1000)
    },
    /*
    * 播放速度设置
    * */
    setPlaySpeed () {
      let uuid = this.model.uuid
      if (this.model._model_obj_name) {
        uuid = this.model[this.model._model_obj_name].uuid
      }
      ModelAnimate.removeTimer(uuid).then(() => {
        let speed = this.options.Speeds[this.playSpeed].val
        let mixer = this.model.mixer
        if (this.model._model_obj_name) {
          mixer = this.model[this.model._model_obj_name].mixer
        }
        ModelAnimate.addTimer(uuid, mixer, speed)
      })
    }
  },
  mounted () {},
  beforeDestroy () {}
}
</script>

<style lang="less">
@import "../../Less/base";
</style>
