<template>
    <div class="PanelSet">
        <!--环境光-->
        <v-layout row wrap class="pa-2">
            <v-flex xs10>
                <v-subheader class="px-0">是否显示环境光</v-subheader>
            </v-flex>
            <v-flex xs2>
                <v-subheader class="px-0">
                    <v-switch v-model="AmbientLight.visible" class="ma-0 pa-0" hide-details></v-switch>
                </v-subheader>
            </v-flex>
        </v-layout>
        <!--网格-->
        <v-layout row wrap class="pa-2">
            <v-flex xs10>
                <v-subheader class="px-0">是否显示网格</v-subheader>
            </v-flex>
            <v-flex xs2>
                <v-subheader class="px-0">
                    <v-switch v-model="DEFAULT_GRID.visible" class="ma-0 pa-0" hide-details></v-switch>
                </v-subheader>
            </v-flex>
        </v-layout>
        <!--相机-->
        <v-layout row wrap class="pa-2">
            <v-flex xs12>
                <v-subheader class="px-0">
                    <span v-text="cameraOptions.name"></span>
                    <v-spacer></v-spacer>
                    <v-btn flat icon color="green" @click.native="resetData('camera')"><font-icon name="reset"></font-icon></v-btn>
                </v-subheader>
            </v-flex>
            <v-flex xs12>
                <v-slider thumb-label :value="cameraOptions.field" @input="setCameraField" :max="cameraOptions.max"></v-slider>
            </v-flex>
        </v-layout>
        <!--背景-->
        <v-layout row wrap class="pa-2">
            <v-flex xs12>
                <v-subheader class="px-0">
                    <span v-text="bgOptions.name"></span>
                    <v-spacer></v-spacer>
                    <v-btn flat icon color="green" @click.native="resetData('background')"><font-icon name="reset"></font-icon></v-btn>
                </v-subheader>
            </v-flex>
            <v-flex xs10>
                <v-subheader class="px-0">是否显示背景</v-subheader>
            </v-flex>
            <v-flex xs2>
                <v-subheader class="px-0">
                    <v-switch v-model="bgOptions.isOpen" @change="clearBg" class="ma-0 pa-0" hide-details></v-switch>
                </v-subheader>
            </v-flex>
            <v-flex xs12 v-show="bgOptions.isOpen">
                <v-select :value="bgOptions.currentType" @input="chanType" :items="bgOptions.menus" hide-selected box></v-select>
            </v-flex>
            <v-flex xs12 v-show="bgOptions.isOpen">
                <template v-if="bgOptions.currentType === 'color'">
                    <sketch-picker disableAlpha
                                   :presetColors="['#D0021B']"
                                   :value="bgOptions.color"
                                   @input="setBgByColor"></sketch-picker>
                </template>
                <template v-if="bgOptions.currentType === 'images'">
                    <v-img class="mb-1"
                           :src="item.src"
                           :key="index"
                           @click="setBgByTexture(item)"
                           v-for="(item,index) in bgOptions.images"></v-img>
                </template>
                <template v-if="bgOptions.currentType === 'environments'">
                    <v-layout row wrap class="pa-0">
                        <v-flex xs12>
                            <v-subheader class="px-0">
                                <span>方向</span>
                            </v-subheader>
                        </v-flex>
                        <v-flex xs12>
                            <v-slider thumb-label :value="bgOptions.Orientation" @input="setOrientation" :max="bgOptions.Orientation_max"></v-slider>
                        </v-flex>
                    </v-layout>
                    <v-img class="mb-1" :src="item.cover" :key="index" v-for="(item,index) in bgOptions.environments" @click="setBgByGeometry(item)"></v-img>
                </template>
            </v-flex>
        </v-layout>
    </div>
</template>

<script>
import { PanelUI } from '@/config/PanelOptions'
import { Sketch } from 'vue-color'
import { SetProperty } from '@/utils/EditorSet'
import _lang from 'lodash/lang'
export default{
  props: {},
  components: {
    'sketch-picker': Sketch
  },
  created () {
    this.bgOptions = _lang.cloneDeep(PanelUI.background)
    this.cameraOptions = _lang.cloneDeep(PanelUI.camera)
  },
  data () {
    return {
      bgOptions: {},
      cameraOptions: {}
    }
  },
  computed: {
    DEFAULT_GRID () {
      return this.$store.state.globalObject.DEFAULT_GRID
    },
    AmbientLight () {
      return this.$store.state.globalObject.AmbientLight
    }
  },
  methods: {
    // 重制相机属性
    resetData (name) {
      if (name === 'camera') {
        this.cameraOptions = _lang.cloneDeep(PanelUI.camera)
        SetProperty.setCameraField(this.cameraOptions.field)
      }
      if (name === 'background') {
        this.bgOptions = _lang.cloneDeep(PanelUI.background)
        this.isOpen = this.bgOptions.isOpen
        this.chanType(this.bgOptions.currentType)
      }
    },
    // 设置相机视野远近
    setCameraField (val) {
      this.cameraOptions.field = parseInt(val)
      SetProperty.setCameraField(val)
    },
    // 清除和设置背景
    clearBg () {
      if (this.bgOptions.isOpen) {
        this.chanType(this.bgOptions.currentType)
      } else {
        SetProperty.setClearBg()
      }
    },
    // 改变背景类型
    chanType (val) {
      this.bgOptions.currentType = val
      if (val === 'color') {
        this.setBgByColor(this.bgOptions.color)
      } else if (val === 'images') {
        this.setBgByTexture(this.bgOptions.images[0])
      } else if (val === 'environments') {
        this.setBgByGeometry(this.bgOptions.environments[0])
      }
    },
    // 通过颜色设置背景
    setBgByColor (val) {
      this.bgOptions.color = val
      SetProperty.setBgByColor(val.hex || val)
    },
    // 通过背景图设置背景
    setBgByTexture (item) {
      SetProperty.setBgByTexture(item.src)
    },
    // 设置全景图
    setBgByGeometry (item) {
      SetProperty.setBgByGeometry(item)
    },
    // 给全景背景设置方向
    setOrientation (val) {
      this.bgOptions.Orientation = parseInt(val)
      SetProperty.setBgOrientation(this.bgOptions.Orientation / this.bgOptions.Orientation_max)
    }
  },
  mounted () {},
  beforeDestroy () {}
}
</script>

<style lang="less">
    @import "../../Less/base";
    .PanelSet{
        .vc-sketch{
            -moz-box-sizing: border-box;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            width: 100%;
            box-shadow: 0 0 0 1px rgba(0, 0, 0, .15);
            border-radius: 0;
        }
    }
</style>
