<template>
    <div class="PanelPrototype">

    </div>
</template>

<script>
export default{
  props: {},
  components: {},
  created () {
  },
  data () {
    return {
    }
  },
  methods: {
  },
  mounted () {},
  beforeDestroy () {}
}
</script>

<style lang="less">
@import "../../Less/base";
.PanelPrototype{
}
</style>
