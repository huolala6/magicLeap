<template>
    <v-list class="PanelCoverage elevation-2 pa-0" id="PanelCoverage">
        <v-list-tile v-for="item in coverageList"
                     :key="item.uuid"
                     :class="{'v-list__tile--highlighted':CurrentObject?CurrentObject.uuid === item.uuid:false}">
            <v-list-tile-content @click="selectAction(item)">
                <v-list-tile-title v-text="item.key"></v-list-tile-title>
            </v-list-tile-content>
            <v-list-tile-action @click="deleteModel(item)">
                <font-icon name="delete"></font-icon>
            </v-list-tile-action>
            <v-list-tile-action @click="hideModel(item)">
                <font-icon name="yincang" :class="{hide:item.hide}"></font-icon>
            </v-list-tile-action>
        </v-list-tile>
    </v-list>
</template>

<script>
import { SelectAction, EditorMethods } from '@/utils/EditorMethods'
import PerfectScrollbar from 'perfect-scrollbar'
import 'perfect-scrollbar/css/perfect-scrollbar.css'
let scrollBar = null
export default{
  props: {},
  components: {},
  data () {
    return {}
  },
  computed: {
    coverageList () {
      return this.$store.state.coverageList
    },
    geometryObjects () {
      return this.$store.state.geometryObjects
    },
    lightObjects () {
      return this.$store.state.lightObjects
    },
    ModelObjects () {
      return this.$store.state.ModelObjects
    },
    CurrentObject () {
      return this.$store.state.CurrentObject
    }
  },
  created () {},
  watch: {
    coverageList () {
      if (scrollBar) { scrollBar.update() }
    }
  },
  methods: {
    selectAction (item) {
      SelectAction.selectObject(this[item.storeName][item.uuid])
    },
    hideModel (item) {
      SelectAction.visiableObject(item.storeName, this[item.storeName][item.uuid])
      this.$set(item, 'hide', !item.hide)
    },
    deleteModel (item) {
      EditorMethods.remove(item.storeName, item.uuid)
    }
  },
  mounted () {
    this.$nextTick(() => {
      scrollBar = new PerfectScrollbar('#PanelCoverage')
    })
  },
  beforeDestroy () {
    if (scrollBar) {
      scrollBar.destroy()
      scrollBar = null
    }
  }
}
</script>

<style lang="less">
@import "../../Less/base";
.PanelCoverage{
    max-height: 180px;
    padding-left: 0;
    cursor: pointer;
    position: relative;
    .icon-yincang{
        .mix-font-Size(14);
        color: @mainColor;
        &.hide{
            color: @C8;
        }
    }
    .icon-delete{
        .mix-font-Size(16);
        color: @errColor;
    }
}
</style>
