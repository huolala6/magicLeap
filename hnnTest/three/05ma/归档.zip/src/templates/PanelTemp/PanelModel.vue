<template>
    <div class="PanelModel" >
        <v-card color="grey darken-3 mb-2"
                class="white--text elevation-0"
                v-for="(item,index) in Models"
                @click.native="loadModel(item)"
                :key="index">
            <v-img :src="item.cover" height="160" aspect-ratio="1.7">
                <small v-text="item.type.toUpperCase()" class="PanelModel_model_type"></small>
            </v-img>
            <v-card-title>
                <span v-text="item.title"></span>
            </v-card-title>
        </v-card>
    </div>
</template>

<script>
import { Models } from '@/config/Models'
import { ModelMethods } from '@/utils/ModelMethods'
let clicked = false
export default{
  components: {},
  data () {
    return {
      Models: []
    }
  },
  created () {
    this.Models = Models
  },
  methods: {
    loadModel (item) {
      if (clicked) { return }
      clicked = true
      let fnName = item.type.toUpperCase()
      ModelMethods[fnName](item)
      setTimeout(() => { clicked = false }, 300)
    }
  },
  mounted () {},
  beforeDestroy () {}
}
</script>

<style lang="less">
.PanelModel{
    .PanelModel_model_type{
        padding: 10px;
        color: #fff;
        display: block;
        font-size: 20px;
        text-shadow: 0 0 1px rgba(0,0,0,0.4);
    }
}
</style>
