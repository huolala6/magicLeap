<template>
    <div class="PanelAdd">
        <dl v-for="(group,key) in options" :key="key" :class="{light: key === 'lights'}">
            <dd v-for="(item,index) in group.options" :key="index" @click="createSome(item, key)">
                <font-icon :name="item.icon" v-if="item.icon"></font-icon>
                <span v-else v-text="item.key"></span>
            </dd>
        </dl>
    </div>
</template>

<script>
import { CreateOptions } from '@/config/CreateOptions'
import { CreateGeometry, CreateLight } from '@/utils/EditorAdd'
export default{
  data () {
    return {
      options: []
    }
  },
  created () {
    this.options = CreateOptions
  },
  computed: {
    globalObject () {
      return this.$store.state.globalObject
    }
  },
  methods: {
    createSome (item, key) {
      if (!this.globalObject.DEFAULT_SCENE) { return }
      if (key === 'two_geometry' || key === 'three_geometry') {
        CreateGeometry[item.key](this.globalObject.DEFAULT_SCENE, item.options)
      }
      if (key === 'lights') {
        CreateLight[item.key](this.globalObject.DEFAULT_SCENE, item.options)
      }
    }
  },
  mounted () {},
  beforeDestroy () {}
}
</script>

<style lang="less">
@import "../../Less/base";
.PanelAdd{
    width: 100%;
    dl{
        display: flex;
        justify-content: center;
        margin-bottom: 15px;
        background-color: @C3;
        border-radius: 4px;
        dd{
            padding: 10px 15px;
            cursor: pointer;
            color: #fff;
            &:active{
                background-color: rgba(0,0,0,0.3);
            }
            span{
                font-size: 12px;
            }
        }
        &.light{
            display: block;
            background: transparent;
            border-radius: 0;
            margin-bottom: 0;
            dd{
                display: flex;
                justify-content: center;
                margin-bottom: 15px;
                background-color: @C3;
                border-radius: 4px;
            }
        }
    }
}
</style>
