<!--属性面板-->
<template>
    <div class="PropertyPanel">
        <v-tabs color="transparent" grow slider-color="blue" v-model="active">
            <v-tab v-for="(item,index) in menus" :key="index">
                <font-icon :name="item.icon"></font-icon>
            </v-tab>
        </v-tabs>
        <div class="PropertyPanel_container" id="Container">
            <PanelAdd class="px-2 py-3" v-show="menus[active].key === 'add'"></PanelAdd>
            <PanelModel class="px-2 py-3" v-show="menus[active].key === 'model'"></PanelModel>
            <PanelCoverage v-show="menus[active].key === 'coverage'"></PanelCoverage>
            <PanelPrototype v-show="menus[active].key === 'coverage'"></PanelPrototype>
            <PanelAnimation v-show="menus[active].key === 'animation'"></PanelAnimation>
            <PanelSet v-show="menus[active].key === 'setting'"></PanelSet>
        </div>
    </div>
</template>

<script>
import { PanelUI } from '@/config/PanelOptions'
import PanelAdd from './PanelTemp/PanelAdd'
import PanelCoverage from './PanelTemp/PanelCoverage'
import PanelModel from './PanelTemp/PanelModel'
import PanelPrototype from './PanelTemp/PanelPrototype'
import PanelAnimation from './PanelTemp/PanelAnimation'
import PanelSet from './PanelTemp/PanelSet'
export default{
  components: { PanelAdd, PanelCoverage, PanelModel, PanelPrototype, PanelAnimation, PanelSet },
  created () {
    this.menus = PanelUI.menus
  },
  data () {
    return {
      menus: [],
      active: 1,
      scrollBar: null
    }
  },
  computed: {
    globalObject () {
      return this.$store.state.globalObject
    }
  },
  methods: {},
  mounted () {
  },
  beforeDestroy () {}
}
</script>

<style lang="less">
@import "../Less/base";
.PropertyPanel{
    position: absolute;
    width: 300px;
    height: 100%;
    background-color: @bgColor;
    .PropertyPanel_container{
        width: 100%;
        height: calc(~"100% - 48px");
        .overflow-auto();
    }
}
</style>
