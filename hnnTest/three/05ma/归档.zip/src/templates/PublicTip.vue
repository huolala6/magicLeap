<template>
    <div class="PublicTip">
    </div>
</template>

<script>
export default{
  props: {},
  components: {},
  created () {},
  data () {
    return {}
  },
  methods: {},
  mounted () {},
  beforeDestroy () {}
}
</script>

<style lang="less">
.PublicTip{}
</style>
