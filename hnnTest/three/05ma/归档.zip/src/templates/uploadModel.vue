<template>
    <div class="uploadModel">
        <div v-show="$refs.uploadModel && $refs.uploadModel.dropActive" class="uploadModel_drop_active">
            <h3 class="display-2">放入上传</h3>
        </div>
        <div class="uploadModel_choose">
            <v-subheader class="pl-3 mt-2">
                <span>支持模型格式:GLTF, DAE, FBX, BLENDER, OBJ, BABYLON, ASSIMP, VRML, STL, PLY</span>
                <v-spacer></v-spacer>
                <v-btn flat icon color="deep-orange accent-3" @click.native="close"><font-icon name="close"></font-icon></v-btn>
            </v-subheader>
            <v-divider></v-divider>
            <div class="uploadModel_tip pa-4">
                <h5 class="headline mb-3">拖入单个文件、多个文件、文件夹</h5>
                <file-upload :multiple="true"
                             :drop-directory="true"
                             :drop="true"
                             :accept="options.accept"
                             :size="options.maxSize"
                             :thread="options.thread"
                             ref="uploadModel"
                             @input-filter="inputFilter"
                             @input-file="inputFile"
                             :post-action="requestOptions.postUrl"
                             :headers="requestOptions.headers"
                             :data="requestOptions.data"
                             v-model="files">
                    <v-btn depressed dark color="light-green">选择文件</v-btn>
                </file-upload>
            </div>
            <v-divider></v-divider>
            <v-subheader>
                <v-spacer></v-spacer>
                <v-btn color="grey lighten-1" flat>取消</v-btn>
                <v-btn color="light-green" flat>上传</v-btn>
            </v-subheader>
        </div>

    </div>
</template>

<script>
import VueUploadComponent from 'vue-upload-component'
export default{
  props: {},
  components: {
    'file-upload': VueUploadComponent
  },
  data () {
    return {
      files: [],
      options: {
        thread: 1, // 同时可上传的文件数
        maxSize: 0, // 0代表无限制，单位字节
        accept: '.wrl,.obj,.ive,.3ds,.dae,.ply,.osg2,.osgt,.osgb,.osgx,.osgs,.gem,.geo,.mdl,.rgb,.lws,.dxf,.tgz,.osgterrain,.shp,.zae,.stl,.sta,.bvh,.ac,.flt,.ogr,.osga,.md2,.x,.txp,.dw,.osgtgz,.3dc,.asc,.lw,.lwo,.gdal,.bsp,.osg,.iv,.blend,.blend1,.fbx,.dat,.mc2obj,.dwf,.vpk,.zip,.7z,.rar,.gz,.kmz,.craft,.wrz,.mu,.q3d,.gltf,.glb,.iges,.igs,.abc,.las,.jpg,.jpeg,.png,.tga,.mtl,.psd,.bin'
      },
      requestOptions: {
        postUrl: '',
        headers: {},
        data: {}
      }
    }
  },
  created () {},
  methods: {
    close () {
      this.$emit('closeUpload')
    },
    // 过滤文件
    inputFilter (newFile, oldFile, prevent) {
      console.log('newFile', newFile)
      console.log('oldFile', oldFile)
      console.log('prevent', prevent)
      if (newFile && !oldFile) {
        // Before adding a file
        // 添加文件前
        // Filter system files or hide files
        // 过滤系统文件 和隐藏文件
        if (/(\/|^)(Thumbs\.db|desktop\.ini|\..+)$/.test(newFile.name)) {
          return prevent()
        }
        // Filter php html js file
        // 过滤 php html js 文件
        if (/\.(php5?|html?|jsx?)$/i.test(newFile.name)) {
          return prevent()
        }
      }
      if (newFile && (!oldFile || newFile.file !== oldFile.file)) {
        // Create a blob field
        // 创建 blob 字段
        newFile.blob = ''
        let URL = window.URL || window.webkitURL
        if (URL && URL.createObjectURL) {
          newFile.blob = URL.createObjectURL(newFile.file)
        }
        // Thumbnails
        // 缩略图
        newFile.thumb = ''
        if (newFile.blob && newFile.type.substr(0, 6) === 'image/') {
          newFile.thumb = newFile.blob
        }
      }
    },

    // 选择事件
    inputFile (newFile, oldFile) {
      console.log('newFile', newFile)
      console.log('oldFile', oldFile)
      if (newFile && oldFile) {
        // update
        if (newFile.active && !oldFile.active) {
          // beforeSend
          console.log('beforeSend')
        }
        if (newFile.progress !== oldFile.progress) {
          // progress
          console.log('progress')
        }
        if (newFile.error && !oldFile.error) {
          // error
          console.log('error')
        }
        if (newFile.success && !oldFile.success) {
          // success
          console.log('success')
        }
      }
      if (!newFile && oldFile) {
        // remove
        if (oldFile.success && oldFile.response.id) {
          console.log('remove')
          // $.ajax({
          //   type: 'DELETE',
          //   url: '/upload/delete?id=' + oldFile.response.id,
          // })
        }
      }
    }
  },
  mounted () {},
  beforeDestroy () {}
}
</script>

<style lang="less">
    @import "../Less/base";
    .uploadModel{
        position: fixed;
        top:0;
        left:0;
        z-index: @upload_model_index;
        width: 100%;
        height: 100%;
        background-color: rgba(0,0,0,0.3);
        display: flex;
        align-items: center;
        justify-content: center;
        .uploadModel_drop_active{
            position: fixed;
            top:0;
            left:0;
            z-index: @upload_model_index;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.7);
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fff;
        }
        .uploadModel_choose{
            background-color: @bgColor;
            width: 667px;
            height: 375px;
        }
        .uploadModel_tip{
            height: 259px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
        }
    }
</style>
