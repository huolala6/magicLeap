<template>
    <i class="iconfont" :class="'icon-' + name"></i>
</template>

<script>
import '@/assets/icon/iconfont.css'
export default{
  name: 'font-icon',
  props: {
    name: {
      type: String
    }
  }
}
</script>

<style>

</style>
