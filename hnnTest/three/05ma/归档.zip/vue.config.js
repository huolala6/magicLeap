// 去console插件
const UglifyJsPlugin = require('uglifyjs-webpack-plugin')
module.exports = {
  baseUrl: './',
  outputDir: 'source',
  assetsDir: 'static',
  css: undefined,

  devServer: {
    hot: true
  },

  //  webpack插件配置
  configureWebpack: config => {
    let plugins = [
      // 去除打包后控制台输出
      new UglifyJsPlugin({
        uglifyOptions: {
          compress: {
            warnings: false,
            drop_debugger: true,
            drop_console: true
          }
        },
        sourceMap: false,
        parallel: true
      })
    ]
    if (process.env.NODE_ENV !== 'development') {
      config.plugins = [...config.plugins, ...plugins]
    }
  },

  lintOnSave: undefined,
  runtimeCompiler: undefined,
  productionSourceMap: false,
  parallel: undefined
}
