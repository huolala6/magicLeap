
## Project setup
```
npm install
npm run serve
npm run build
npm run lint
```
